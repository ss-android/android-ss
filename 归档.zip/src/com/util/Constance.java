package com.util;

import com.http.company.NewsApi;

/**
 * @author retryu E-mail:ruanchenyugood@gmail.com
 * @version create time：2013-8-18 上午10:57:47 declare:
 */
public class Constance {
	public static final String domain = "http://cloud.yofoto.cn/index.php";
	public static final String version = "1.0";
	public static final String mac = "";
}
