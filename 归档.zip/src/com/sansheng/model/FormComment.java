package com.sansheng.model;

/**
 * @author retryu E-mail:ruanchenyugood@gmail.com
 * @version create time：2013-9-20 上午11:52:56 declare:
 */
public class FormComment {

	private String userid;
	private String logisticsok;
	private String userlevel;
	private Evaluate eveEvaluate;

}
