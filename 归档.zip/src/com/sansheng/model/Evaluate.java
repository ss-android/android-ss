package com.sansheng.model;
/**
 * @author retryu E-mail:ruanchenyugood@gmail.com
 * @version create time：2013-8-31 下午8:47:34
 * declare:
 */
public class Evaluate {

}
