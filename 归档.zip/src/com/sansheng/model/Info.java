package com.sansheng.model;
/**
 * @author retryu E-mail:ruanchenyugood@gmail.com
 * @version create time：2013-8-18 下午2:25:02
 * declare:
 */
public class Info {
	
	
	private String retcode;
	

}
