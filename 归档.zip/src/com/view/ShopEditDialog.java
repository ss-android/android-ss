package com.view;

import android.app.Dialog;
import android.content.Context;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.lekoko.sansheng.R;
import com.sansheng.model.Product;

/**
 * @author retryu E-mail:ruanchenyugood@gmail.com
 * @version create time：2013-9-7 下午12:05:08 declare:
 */
public class ShopEditDialog extends Dialog implements
		android.view.View.OnClickListener {

	private Button btnFinish;
	private Button btnAdd;
	private Button btnDelete;
	private Product product;

	private EditText etNumber;

	private onDissmissListner onDissmissListner;

	public ShopEditDialog(Context context) {
		super(context, R.style.NOTitleDialog);
		setContentView(R.layout.layout_dialog_edit_shop_number);
		btnFinish = (Button) findViewById(R.id.Btn_Finish);
		btnAdd = (Button) findViewById(R.id.Btn_Add_Number);
		btnDelete = (Button) findViewById(R.id.Btn_Delete_Number);
		etNumber = (EditText) findViewById(R.id.Et_Number);

		btnDelete.setOnClickListener(this);
		btnFinish.setOnClickListener(this);
		btnAdd.setOnClickListener(this);
	}

	public void show(Product p) {
		this.product = p;
		etNumber.setText(p.getMun() + "");
		show();
	}

	@Override
	public void onClick(View v) {
		int id = v.getId();
		int number;
		switch (id) {
		case R.id.Btn_Finish:
			onDissmissListner.OnDissMiss(product);
			dismiss();
			break;

		case R.id.Btn_Add_Number:
			number =product.getMun();
			number++;
			product.setMun(number);
			etNumber.setText(product.getMun() + "");
			break;

		case R.id.Btn_Delete_Number:
			number =  product.getMun();
			if (number > 0) {
				number--;
				product.setMun(number);
				etNumber.setText(product.getMun() + "");
			}

			break;
		}

	}

	public onDissmissListner getOnDissmissListner() {
		return onDissmissListner;
	}

	public void setOnDissmissListner(onDissmissListner onDissmissListner) {
		this.onDissmissListner = onDissmissListner;
	}

	public interface onDissmissListner {
		public void OnDissMiss(Product product);

	}
}
