package com.activity.company.community;

public class community {
	private String commnuityTitile;
	private int drawable;

	public String getCommnuityTitile() {
		return commnuityTitile;
	}

	public void setCommnuityTitile(String commnuityTitile) {
		this.commnuityTitile = commnuityTitile;
	}

	public int getDrawable() {
		return drawable;
	}

	public void setDrawable(int drawable) {
		this.drawable = drawable;
	}

}
