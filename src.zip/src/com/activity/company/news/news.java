package com.activity.company.news;

/**
 * @author retryu E-mail:ruanchenyugood@gmail.com
 * @version create time：2013-8-17 上午11:50:05 declare:
 */
public class news {
	private String newTitile;
	private int drawable;

	public String getNewTitile() {
		return newTitile;
	}

	public void setNewTitile(String newTitile) {
		this.newTitile = newTitile;
	}

	public int getDrawable() {
		return drawable;
	}

	public void setDrawable(int drawable) {
		this.drawable = drawable;
	}

}
