package com.activity.achievements;

import android.os.Bundle;

import com.activity.CommonActivity;

/**
 * @author retryu E-mail:ruanchenyugood@gmail.com
 * @version create time：2013-8-21 下午9:20:24
 * declare:业绩查询主页
 */
public class AchrivementIndexActivity   extends  CommonActivity{
	@Override
	protected void onCreate(Bundle arg0) {
		// TODO Auto-generated method stub
		super.onCreate(arg0);
	
	
	}

}
