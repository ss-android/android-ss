package com.activity.setting.bindsetting.wx;
/**
 * @author retryu E-mail:ruanchenyugood@gmail.com
 * @version create time：2013-8-15 下午9:20:29
 * declare:
 */
public class WxLogingActivity {

}
  