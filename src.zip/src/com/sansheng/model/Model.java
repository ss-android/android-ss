package com.sansheng.model;
/**
 * @author retryu E-mail:ruanchenyugood@gmail.com
 * @version create time：2013-9-8 上午10:58:41
 * declare:
 */
public class Model {

}
