package com.sansheng.dao.interfaze;

import com.j256.ormlite.dao.Dao;
import com.sansheng.model.Logistics;

public interface LogisticsDao extends Dao<Logistics, String> {

	
	
	
}
