package com.sansheng.dao.interfaze;

import com.j256.ormlite.dao.Dao;
import com.sansheng.model.Plan;

public interface PlanDao extends Dao<Plan, String> {

}
