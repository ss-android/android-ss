package com.sansheng.dao.interfaze;

import com.j256.ormlite.dao.Dao;
import com.sansheng.model.User;

/**
 * @author retryu E-mail:ruanchenyugood@gmail.com
 * @version create time：2013-8-25 下午8:49:07
 * declare:
 */
public interface UserDao extends Dao<User, String>  {

}
