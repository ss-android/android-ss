package com.http.task;

import android.os.AsyncTask;

import com.activity.CommonActivity;
import com.http.BaseRequest;
import com.http.ShopService;
import com.http.ViewCommonResponse;

public class ShopAsyncTask extends
		AsyncTask<BaseRequest, Void, ViewCommonResponse> {
	private CommonActivity activity;
	ShopService shopService = new ShopService();

	public ShopAsyncTask(CommonActivity activity) {
		this.activity = activity;
	}

	@Override
	protected ViewCommonResponse doInBackground(BaseRequest... params) {
		ViewCommonResponse viewCommonResponse = null;

		if (params[0] != null) {
			int action = params[0].getAction();
			switch (action) {
			case ShopService.SHOP_PRBC_LIST:
				viewCommonResponse = shopService.getPrbsList();
				break;
			case ShopService.SHOP_PRBC_SERIZAL:
				viewCommonResponse = shopService.getSerizleProduct(params[0]
						.getParams());
				break;
			case ShopService.SHOP_BRAND:
				viewCommonResponse = shopService.getBrandInfo(params[0]
						.getParams());
				break;
			case ShopService.PRODUCT_INFO:
				viewCommonResponse = shopService.getProductSimpleInfo(params[0]
						.getParams());
				break;
			case ShopService.PRODUCT_DETAIL:
				viewCommonResponse = shopService.getProductDetail(params[0]
						.getParams());
				break;
			case ShopService.PRODUCT_COMMENT:
				viewCommonResponse = shopService.getProductComment(params[0]
						.getParams());

				break;
			case ShopService.PRODUCT_ADD:
				viewCommonResponse = shopService.addShop(params[0].getParams());

				break;
			case ShopService.SHOP_CAR_LIST:
				viewCommonResponse = shopService
						.quryShop(params[0].getParams());

				break;

			}

			viewCommonResponse.setAction(action);
		}
		return viewCommonResponse;
	}

	@Override
	protected void onPostExecute(ViewCommonResponse result) {
		activity.refresh(result);
		super.onPostExecute(result);
	}

	@Override
	protected void onPreExecute() {
		super.onPreExecute();
	}

}